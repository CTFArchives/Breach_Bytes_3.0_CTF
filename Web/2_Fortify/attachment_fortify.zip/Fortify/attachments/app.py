from flask import Flask, request, render_template, redirect
from urllib.parse import urlparse
import requests

app = Flask(__name__)

FLAG = "Th3_d3v1l_1s_1n_th3_d3tA1ls_4nd_th3_l0gs"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url_to_scan = request.form.get('url')
        if not url_to_scan:
            return render_template('index.html', error="URL field cannot be empty.")

        try:
            parsed_url = urlparse(url_to_scan)
            if parsed_url.netloc != request.host:
                return render_template(
                    'index.html',
                    error=f"Error: For security reasons, this tool is restricted to scanning only this host ({request.host}). "
                          "This prevents misuse and protects our identifier tokens."
                )

            if parsed_url.scheme not in ['http', 'https']:
                return render_template(
                    'index.html',
                    error="Error: Only HTTP and HTTPS URLs are supported."
                )
        except Exception:
            return render_template('index.html', error="Invalid URL format.")
        
        status = "Offline"
        try:
            res = requests.get(
                url_to_scan, 
                timeout=3, 
                allow_redirects=True,
                cookies={'flag': FLAG}
            )
            if res.ok:
                status = "Online"
        except requests.exceptions.RequestException:
            status = "Offline (Connection Error)"

        return render_template('result.html', url=url_to_scan, status=status)

    return render_template('index.html')

@app.route('/api/v1/tracker')
def api_tracker():
    url_to = request.args.get('next')
    if not url_to:
        return render_template('tracker_info.html')

    if 'http://' in url_to.lower():
        print("http urrl")
        return "Security policy: insecure protocols are forbidden.", 403

    if 'webhook' in url_to.lower():
        return "Security policy: The 'webhook' domain have been flaged due to abuse reports.", 403

    return redirect(url_to)


@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

