from flask import Flask, render_template, request, redirect, url_for, session, make_response, g
from lxml import etree
import json
import os
import re

app = Flask(__name__)
app.secret_key = 'zb3[8e1oppA+Y-1,,Nz3FO1;nWTC]0PN5F3P+rAln&QMYkRZXp'

def load_users():
    if not os.path.exists('users.json'): return []
    with open('users.json', 'r') as f: return json.load(f)

def save_users(users):
    with open('users.json', 'w') as f: json.dump(users, f, indent=4)

def is_valid_username(username):
    return re.match(r'^[a-zA-Z0-9]{3,20}$', username) is not None

@app.before_request
def before_request():
    g.user = None
    if 'user_id' in session:
        users = load_users()
        g.user = next((user for user in users if user['id'] == session['user_id']), None)

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if not is_valid_username(username):
            error = "Username must be alphanumeric and 3-20 characters long."
        else:
            users = load_users()
            if any(user['username'].lower() == username.lower() for user in users):
                error = "Username already exists."
            else:
                new_id = len(users) + 123
                new_user = {"id": new_id, "username": username, "password": password, "beta_token": None}
                users.append(new_user)
                save_users(users)
                return redirect(url_for('login'))
    return render_template('register.html', error=error)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        user = next((u for u in users if u['username'] == username and u['password'] == password), None)
        if user:
            session['user_id'] = user['id']
            session['is_beta_tester'] = False
            return redirect(url_for('dashboard', user_id=user['id']))
        else:
            error = "Invalid username or password."
    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    if not g.user:
        return redirect(url_for('login'))
    try:
        requested_user_id = int(request.args.get('user_id'))
    except (ValueError, TypeError):
        return "Invalid user ID.", 400
    users = load_users()
    dashboard_user_data = next((user for user in users if user['id'] == requested_user_id), None)
    if not dashboard_user_data:
        return "User not found!", 404
    is_admin_dashboard = (dashboard_user_data['username'] == 'admin')
    beta_token = dashboard_user_data.get('beta_token') if is_admin_dashboard else None
    return render_template('dashboard.html', dashboard_user=dashboard_user_data, is_beta_tester=session.get('is_beta_tester', False), beta_token=beta_token)

@app.route('/check_beta_key', methods=['POST'])
def check_beta_key():
    if not g.user:
        return redirect(url_for('login'))
    beta_key = request.form.get('beta_key')
    users = load_users()
    admin_user = next((user for user in users if user['username'] == 'admin'), None)
    if admin_user and beta_key == admin_user.get('beta_token'):
        session['is_beta_tester'] = True
    else:
        return redirect(url_for('dashboard', user_id=session['user_id'], error="Invalid Beta Key"))
    return redirect(url_for('dashboard', user_id=session['user_id']))

@app.route('/xmlparser', methods=['GET', 'POST'])
def xml_parser():
    if not g.user:
        return redirect(url_for('login'))

    if not session.get('is_beta_tester'):
        return render_template('access_denied.html'), 403

    parsed_output = None
    if request.method == 'POST':
        xml_data = request.form.get('xml_data', '')
        try:
            parser = etree.XMLParser(load_dtd=True, no_network=False, resolve_entities=True)
            doc = etree.fromstring(xml_data.encode('utf-8'), parser=parser)
            parsed_output = etree.tostring(doc, pretty_print=True).decode('utf-8')
        except etree.XMLSyntaxError as e:
            parsed_output = f"XML Syntax Error: {e}"
        except Exception as e:
            parsed_output = f"An unexpected error occurred: {e}"

    return render_template('xml_parser.html', parsed_output=parsed_output)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)