from flask import Flask, render_template, request, redirect, url_for, make_response, g, jsonify
import jwt
import datetime
import hashlib

# --- Application Setup & Hardening Constants ---
app = Flask(__name__)
app.config['SECRET_KEY'] = 'a-very-official-but-insecure-secret-key' 

# The required role is now a global constant for easy rotation.
REQUIRED_ROLE = "captainoftheship"

# --- In-Memory Database ---
users = {}

# --- Helper Functions ---
def find_user_by_id(user_id):
    for username, data in users.items():
        if data.get('id') == user_id:
            return {**data, 'username': username}
    return None

# --- JWT Authentication ---
def token_required(f):
    def decorated(*args, **kwargs):
        token = request.cookies.get('token')
        if not token:
            return redirect(url_for('login_page'))
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            # The decorator decodes the token but the application logic will
            # only trust the user_id for its checks, not the role.
            g.current_user_id = data['user_id']
        except Exception:
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    decorated.__name__ = f.__name__
    return decorated

# --- Page Rendering Routes ---
@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/register')
def register_page():
    return render_template('register.html')

@app.route('/')
@token_required
def home():
    return render_template('index.html')

@app.route('/flag')
@token_required
def flag_page():
    user_from_db = find_user_by_id(g.current_user_id)
    
    is_captain = user_from_db and user_from_db.get('role') == REQUIRED_ROLE
    
    flag_or_message = "FLAG{API_0bfu5c4t10n_D03snt_St0p_M3}" if is_captain \
        else "Your token is missing the correct role for this resource."
        
    return render_template('flag.html', is_captain=is_captain, flag_or_message=flag_or_message)

@app.route('/development')
@token_required
def development_page():
    return render_template('development.html')

@app.route('/logout')
def logout():
    response = make_response(redirect(url_for('login_page')))
    response.set_cookie('token', '', expires=0)
    return response

# --- API Endpoints ---
@app.route('/auth/v1/provision_new_user_account', methods=['POST'])
def api_register():
    data = request.get_json()
    username = data.get('username')
    
    if not username or not data.get('password'):
        return jsonify({'status': 'error', 'message': 'Username and Password fields are mandatory.'}), 400

    if not username.isalnum():
        return jsonify({'status': 'error', 'message': 'Invalid username. Only alphanumeric characters are allowed.'}), 400

    if username in users:
        return jsonify({'status': 'error', 'message': 'Username is already in use.'}), 409

    user_id = hashlib.md5(username.encode()).hexdigest()
    new_user = {'id': user_id}
    for key, value in data.items():
        new_user[key] = value
    if 'role' not in new_user:
        new_user['role'] = 'user'

    users[username] = new_user
    return jsonify({'status': 'success', 'message': 'User Account Provisioned Successfully.'}), 201

@app.route('/auth/v1/generate_session_token', methods=['POST'])
def api_login():
    data = request.get_json()
    username, password = data.get('username'), data.get('password')
    user = users.get(username)
    if user and user.get('password') == password:
        token = jwt.encode({
            'user_id': user['id'],
            'role': user.get('role', 'user'),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        }, app.config['SECRET_KEY'], algorithm="HS256")
        
        return jsonify({'status': 'success', 'token': token, 'user_id': user['id']})
    
    return jsonify({'status': 'error', 'message': 'Invalid User Credentials.'}), 401

@app.route('/data/v2/query_user_identity_record/<user_id>', methods=['GET'])
@token_required
def get_user_details(user_id):
    user_data = find_user_by_id(user_id)
    if user_data:
        return jsonify({
            'id': user_data.get('id'),
            'username': user_data.get('username'),
            'role': user_data.get('role')
        })
    return jsonify({'error': 'User ID not found in system records.'}), 404

# --- Main Execution ---
if __name__ == '__main__':
    admin_username = 'admin'
    users[admin_username] = {
        'id': hashlib.md5(admin_username.encode()).hexdigest(),
        'password': 'p@55w0rd_Th@t_1s_V3ry_L0ng!!!',
        'role': REQUIRED_ROLE
    }
    app.run(debug=True, port=5003)