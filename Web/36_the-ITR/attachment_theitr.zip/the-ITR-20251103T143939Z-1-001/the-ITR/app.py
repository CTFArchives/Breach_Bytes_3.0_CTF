# app.py (Updated Version)

from flask import Flask, request, jsonify, make_response, redirect, url_for, render_template, Response
import jwt
import datetime
import base64
import os
from pathlib import Path
import hashlib, sys

# imports required for manual HS256 verification
import hmac
import hashlib as _hashlib
import json
import time
import glob

app = Flask(__name__)

# ----- CTF Flag (not in source). Load from env or flag.txt -----
FLAG = os.environ.get('CTF_FLAG')
if not FLAG:
    try:
        with open('flag.txt', 'r', encoding='utf-8') as f:
            FLAG = f.read().strip()
    except Exception:
        FLAG = 'DJSISACA{B@s!c_JWT_Vulner@b1l1ty}'

# ----- RSA keypair (loaded from files in the same folder as this script) -----
ROOT = Path(__file__).resolve().parent
priv_path = ROOT / "private.pem"
pub_path  = ROOT / "public.pem"

try:
    PRIVATE_KEY = priv_path.read_text(encoding='utf-8')
except Exception as e:
    PRIVATE_KEY = None
    print(f"[BOOT] WARNING: private.pem not found at {priv_path} ({e})", file=sys.stderr)

try:
    PUBLIC_KEY = pub_path.read_text(encoding='utf-8')
except Exception as e:
    PUBLIC_KEY = None
    print(f"[BOOT] WARNING: public.pem not found at {pub_path} ({e})", file=sys.stderr)

def _fp(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()[:16] if s else "<NONE>"

print(f"[BOOT] PRIVATE_KEY_fp={_fp(PRIVATE_KEY)} PUBLIC_KEY_fp={_fp(PUBLIC_KEY)}", file=sys.stderr)

# ----- Load keys/ directory into kid -> PEM map -----
KEYS_DIR = ROOT / "keys"   # create a keys/ dir with key1.pem, key2.pem, etc.
KID_TO_PUB = {}

if KEYS_DIR.exists() and KEYS_DIR.is_dir():
    for p in glob.glob(str(KEYS_DIR / "*.pem")):
        kp = Path(p)
        kid = kp.stem
        try:
            KID_TO_PUB[kid] = kp.read_text(encoding='utf-8')
        except Exception as e:
            print(f"[BOOT] could not read key {kp}: {e}", file=sys.stderr)

print(f"[BOOT] Loaded KIDs: {list(KID_TO_PUB.keys())}", file=sys.stderr)

# --- configure which kid(s) allow HS256 (vulnerable kid) ---
VULN_KID = "key3"   # <-- set this to whichever one you want vulnerable

# By default: every kid only allows RS256
KID_ALLOWED_ALGS = {k: {"RS256"} for k in KID_TO_PUB.keys()}

# Add HS256 only for the chosen vulnerable kid
if VULN_KID in KID_ALLOWED_ALGS:
    KID_ALLOWED_ALGS[VULN_KID].add("HS256")

print(f"[BOOT] KID_ALLOWED_ALGS={KID_ALLOWED_ALGS}", file=sys.stderr)

# ----- Helper: create a token signed with RS256 or HS256 (timezone-aware, integer timestamps) -----
def create_token(username, role="user", alg="RS256", kid=None):
    """
    Create a token for testing / CTF use.

    alg: "RS256" or "HS256"
    kid: optional string, included in header and used to choose the verification key/secret
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    iat = int(now.timestamp())
    exp = int((now + datetime.timedelta(hours=1)).timestamp())
    payload = {
        "sub": username,
        "role": role,
        "iat": iat,
        "exp": exp
    }
    headers = {}
    if kid:
        headers['kid'] = kid

    alg = (alg or "RS256").upper()
    if alg == "RS256":
        if not PRIVATE_KEY:
            raise RuntimeError("Server private key not loaded; cannot create RS256 token.")
        token = jwt.encode(payload, PRIVATE_KEY, algorithm="RS256", headers=headers)
    elif alg == "HS256":
        # For CTF/testing: use the specified kid's public-key text bytes as the HMAC secret
        if not kid or kid not in KID_TO_PUB:
            raise RuntimeError("HS256 creation requires an existing kid in keys/ (kid missing or not loaded).")
        secret = KID_TO_PUB[kid].encode('utf-8')
        token = jwt.encode(payload, secret, algorithm="HS256", headers=headers)
    else:
        raise ValueError("Unsupported alg; use 'RS256' or 'HS256'")

    if isinstance(token, bytes):
        token = token.decode('utf-8')
    return token

# ----- Manual helper for base64url decode -----
def _b64url_decode(s: str) -> bytes:
    rem = len(s) % 4
    if rem:
        s += '=' * (4 - rem)
    return base64.urlsafe_b64decode(s.encode('utf-8'))

# ----- Vulnerable verify: manual HS256 (using kid) or RS256 via PyJWT -----
def verify_token(token):
    if not token:
        print("[DEBUG] verify_token called with empty token", file=sys.stderr)
        return None

    # If token was passed like "Bearer <token>", strip prefix
    if isinstance(token, str) and token.startswith("Bearer "):
        token = token[len("Bearer "):]

    try:
        # peek header
        try:
            header = jwt.get_unverified_header(token)
        except Exception as e:
            header = {"error": f"bad header: {e}"}

        fp = hashlib.sha256(PUBLIC_KEY.encode('utf-8')).hexdigest()[:16] if PUBLIC_KEY else "<PUBLIC_KEY is None>"
        print(f"[DEBUG] verify_token called; token_header={header}; PUBLIC_KEY_fp={fp}", file=sys.stderr)

        alg = header.get('alg', '').upper()
        kid = header.get('kid')
        print(f"[DEBUG] verify_token: alg={alg}, kid={kid}, known_kids={list(KID_TO_PUB.keys())}", file=sys.stderr)

        # resolve selected public PEM (or secret) using kid
        selected_pub = None
        if kid:
            selected_pub = KID_TO_PUB.get(kid)
            if not selected_pub:
                print("[DEBUG] kid provided but not found in KID_TO_PUB", file=sys.stderr)

        # fallback to global PUBLIC_KEY if no kid matched
        if not selected_pub and PUBLIC_KEY:
            selected_pub = PUBLIC_KEY
            print("[DEBUG] falling back to server PUBLIC_KEY for verification", file=sys.stderr)

        # Manual HS256 handling (use selected_pub bytes as HMAC secret)
        if alg == "HS256":
            if not selected_pub:
                print("[DEBUG] HS256 requested but no public key (secret) available for HMAC", file=sys.stderr)
                return None

            parts = token.split('.')
            if len(parts) != 3:
                print("[DEBUG] malformed token parts", file=sys.stderr)
                return None

            signing_input = (parts[0] + '.' + parts[1]).encode('utf-8')
            try:
                signature = _b64url_decode(parts[2])
            except Exception as e:
                print(f"[DEBUG] bad signature b64: {e}", file=sys.stderr)
                return None

            secret = selected_pub.encode('utf-8')  # raw PEM bytes as HMAC secret
            expected = hmac.new(secret, signing_input, _hashlib.sha256).digest()

            if not hmac.compare_digest(expected, signature):
                print("[DEBUG] HS256 signature mismatch", file=sys.stderr)
                return None

            # parse payload and do basic time checks
            try:
                payload_json = _b64url_decode(parts[1]).decode('utf-8')
                payload = json.loads(payload_json)
            except Exception as e:
                print(f"[DEBUG] payload decode error: {e}", file=sys.stderr)
                return None

            now_ts = int(time.time())
            if 'exp' in payload and int(payload['exp']) < now_ts:
                print("[DEBUG] token expired", file=sys.stderr)
                return None
            if 'iat' in payload and int(payload['iat']) > now_ts + 60:
                print("[DEBUG] token iat in future", file=sys.stderr)
                return None

            print("[DEBUG] manual HS256 verify succeeded; payload keys=", list(payload.keys()), file=sys.stderr)
            return payload
        # Otherwise attempt RS256 verification with PyJWT using selected_pub as public key
        if not selected_pub:
            print("[DEBUG] RS256 requested but no public key available", file=sys.stderr)
            return None

        payload = jwt.decode(token, selected_pub, algorithms=["RS256"], options={"verify_aud": False})
        print(f"[DEBUG] RS256 jwt.decode succeeded; payload keys={list(payload.keys())}", file=sys.stderr)
        return payload

    except jwt.ExpiredSignatureError:
        print("[DEBUG] token expired (jwt)", file=sys.stderr)
        return None
    except Exception as e:
        print(f"[DEBUG] jwt.decode exception: {type(e).__name__}: {e}", file=sys.stderr)
        return None

# ----- Routes -----
@app.route('/sitemap.xml', methods=['GET'])
def sitemap():
    """Generate a sitemap.xml dynamically."""
    # Base URL (change if deploying to a real domain)
    base_url = request.url_root.rstrip('/')

    # List of important routes to include
    pages = [
        '',  # homepage
        'login',
        'profile',
        'admin',
        'jwks.json',
        'keys'
        ]

    xml_entries = ""
    for page in pages:
        url = f"{base_url}/{page}" if page else base_url
        xml_entries += f"""
   <url>
      <loc>{url}</loc>
      <changefreq>weekly</changefreq>
      <priority>0.8</priority>
   </url>"""

    sitemap_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{xml_entries}
</urlset>"""

    return Response(sitemap_xml, mimetype='application/xml')

@app.route('/')
def index():
    resp = make_response(render_template('index.html'))
    # Preserve original headers/cookies as they might be intentional hints
    resp.set_cookie('session_id', 'guest-session-abcdef123456')
    fake_jwt = base64.urlsafe_b64encode(b"header").decode('utf-8').rstrip('=') + '.' + \
               base64.urlsafe_b64encode(b"payload").decode('utf-8').rstrip('=') + '.' + \
               base64.urlsafe_b64encode(b"sig").decode('utf-8').rstrip('=')
    resp.set_cookie('weird_token', fake_jwt)
    resp.headers['X-Service-Version'] = 'nebula-1.4.2'
    resp.headers['X-Debug-Mode'] = 'true'
    resp.headers['X-Note'] = 'Public key available at /public.pem'
    return resp

@app.route('/jwks.json')
def jwks():
    out = {k: v for k, v in KID_TO_PUB.items()}
    return jsonify(kids=out)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    username = request.form.get('username', 'guest')
    token = create_token(username, role='user')  # default RS256
    resp = make_response(redirect(url_for('profile')))
    resp.set_cookie('auth_token', token)
    resp.headers['X-Initial-JWT'] = token
    return resp

@app.route('/profile')
def profile():
    token = request.cookies.get('auth_token') or request.headers.get('Authorization')
    payload = None
    if token:
        if isinstance(token, str) and token.startswith('Bearer '):
            token = token[len('Bearer '):]
        payload = verify_token(token)

    display_user = None
    if payload:
        display_user = {
            'sub': payload.get('sub'),
            'role': payload.get('role'),
            'iat': datetime.datetime.fromtimestamp(payload.get('iat', 0), tz=datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),
            'exp': datetime.datetime.fromtimestamp(payload.get('exp', 0), tz=datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
        }

    return render_template('profile.html', user=display_user)

@app.route('/admin')
def admin():
    token = request.cookies.get('auth_token') or request.headers.get('Authorization')
    if token and isinstance(token, str) and token.startswith('Bearer '):
        token = token[len('Bearer '):]
    payload = verify_token(token) if token else None
    resp = make_response()
    resp.headers['X-Server-TZ'] = 'UTC'
    resp.headers['X-Trace-Id'] = 'trace-0001'

    if not payload:
        return render_template('admin_denied.html', reason="A valid session cookie is required."), 403

    if payload.get('role') != 'admin':
        return render_template('admin_denied.html', reason="Your user role ('{}') is insufficient.".format(payload.get('role'))), 403

    return render_template('admin_success.html', flag=FLAG)


if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)