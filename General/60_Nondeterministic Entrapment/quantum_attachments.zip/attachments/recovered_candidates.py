arr = [] # enter the values recovered from reversing the probability to ensure that the probability = 1

arr[0] += -1
arr[1] += 0
arr[2] += 1
arr[3] += 1
arr[4] += 0
arr[5] += -2
arr[6] += 0
arr[7] += -3
arr[8] += 0
arr[9] += -1
arr[10] += -2
arr[11] += 2
arr[12] += -3
arr[13] += 1
arr[14] += -3
arr[15] += 0
arr[16] += -1
arr[17] += -2
arr[18] += 0
arr[19] += -1
arr[20] += 34
arr[21] += 2
arr[22] += 1
arr[23] += -2
arr[24] += 1
arr[25] += 12
arr[26] += 26
arr[27] += -2
arr[28] += -1
arr[29] += 1

print(arr)

